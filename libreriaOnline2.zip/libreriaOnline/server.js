import express from 'express';
import catalogoLibri from './model/catalogo.js';
import clientiFile from './model/clienti.js';
import bodyParser from 'body-parser';


const app = express();
app.use(bodyParser.json());
const PORT = 3000;
const BASE_PATH = "/api/v1";

// creo una copia del catalogo per poterlo modificare
var catalogo = [...catalogoLibri];
// creo una copia dell'array dei clienti per poterlo modificare
var clienti = [...clientiFile];


// avvia il server
app.listen(PORT, () => {
    console.log("Server attivo sulla porta " + PORT);
});


// endpoint per restituire un testo di prova
app.get("/", (req, res) => {
    res.send("Benvenuto nella tua libreria online!");
});


// endpoint per recuperare l'intero catalogo dei libri
app.get(`${BASE_PATH}/libri`, (req, res) => {
    res.json(catalogo);
});


// endpoint per recuperare l'elenco dei clienti
app.get(`${BASE_PATH}/clienti`, (req, res) => {
    res.json(clienti);
});


// ricerca per titolo: /v1/libri/search?titolo=restful
app.get(`${BASE_PATH}/libri/search`, (req, res) => {
    // recupero il parametro dall'url
    let titoloParam = (req.query.titolo || "").toString().trim().toLowerCase();

    // se non c'è il parametro, restituisco stato 400 (Bad Request)
    if (!titoloParam) {
        return res.status(400).json({ error: "Parametro 'titolo' errato" });
    }

    let results = catalogo.filter(libro => libro.titolo.toLowerCase().includes(titoloParam));

    res.json(results);
});


// ricerca un libro per id
app.get(`${BASE_PATH}/libri/:id`, (req, res) => {
    // recupero il parametro dall'url e lo converto in numero
    let idParam = parseInt(req.params.id);

    let libroTrovato = catalogo.find(libro => libro.id === idParam);

    if (!libroTrovato) {
        res.status(404).json({ error: "Libro non trovato"});
    } else {
        res.json(libroTrovato);
    }
});


// endpoint per aggiungere un nuovo libro al catalogo
app.post(`${BASE_PATH}/libri`, (req, res) => {
    // recupero i dati del nuovo libro dal corpo della request
    const nuovoLibro = req.body;

    // controllo che il nuovo libro esista
    if (!nuovoLibro) {
        res.status(400).json({ error: 'Nessun dato fornito' });
        return;
    }

    // aggiungo il nuovo libro all'array e restituisco 201 all'utente
    catalogo.push(nuovoLibro);
    res.status(201).json({ message: 'Libro aggiunto con successo' });
});